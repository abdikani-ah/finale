<?php
__('front_cron_completed');
?>